//
//  MovieCollectionViewCell.swift
//  MovieCVApp
//
//  Created by student on 4/12/22.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
   
    
    
    func assignMovies(with movie: Movie){
        image.image = movie.image
    }
    
    @IBOutlet weak var image: UIImageView!
    
    
    
    
    
    
    
}
